const express=require('express');
const path=require('path');
const app=express();
const PORT=process.env.PORT||3000;
app.use(express.json());
const projects=[
    {id:1,title:"InstaAid – Healthcare Booking",desc:"Full-stack platform with doctor, nurse, ambulance booking and tracking.",tech:"Node.js, Express, HTML, CSS, JS"},
    {id:2,title:"IoT Environmental Monitoring",desc:"IoT sensors for real-time air quality, temperature and humidity tracking.",tech:"Arduino, Python, MQTT"},
    {id:3,title:"Java DSA Practice",desc:"200+ LeetCode problems solved with optimized Java solutions.",tech:"Java"}
];
app.get('/api/projects',(req,res)=>{res.json(projects);});
app.post('/api/contact',(req,res)=>{
    const {name,email,message}=req.body;
    if(!name||!email||!message){return res.status(400).json({error:'Missing required fields.'});}
    console.log('Contact form received:',{name,email,message});
    res.json({message:'Thank you! Your message has been received.'});
});
app.use('/',express.static(path.join(__dirname,'..','frontend')));
app.listen(PORT,()=>console.log(`Server running on port ${PORT}`));
