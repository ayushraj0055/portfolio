async function loadProjects(){
    try{
        const res=await fetch('/api/projects');
        const data=await res.json();
        const container=document.getElementById('projects-container');
        container.innerHTML='';
        data.forEach(p=>{
            const div=document.createElement('div');
            div.className='card';
            div.innerHTML=`<h3>${p.title}</h3><p>${p.desc}</p><p><strong>Tech:</strong> ${p.tech}</p>`;
            container.appendChild(div);
        });
    }catch(e){console.error(e);}
}

document.addEventListener('DOMContentLoaded',()=>{
    loadProjects();
    const form=document.getElementById('contactForm');
    const status=document.getElementById('formStatus');
    form.addEventListener('submit',async(e)=>{
        e.preventDefault();
        status.textContent='Sending...';
        const payload={
            name:document.getElementById('nameInput').value,
            email:document.getElementById('emailInput').value,
            message:document.getElementById('messageInput').value
        };
        try{
            const res=await fetch('/api/contact',{
                method:'POST',
                headers:{'Content-Type':'application/json'},
                body:JSON.stringify(payload)
            });
            const json=await res.json();
            if(res.ok){
                status.style.color='green';
                status.textContent=json.message||'Message sent successfully.';
                form.reset();
            }else{
                status.style.color='red';
                status.textContent=json.error||'Failed to send message.';
            }
        }catch(err){
            status.style.color='red';
            status.textContent='Error sending message.';
        }
    });
});
